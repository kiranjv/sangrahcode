<?php
error_reporting(1);
//CHECKING FOR SERVER IS UP OR NOT BY PINGING THE HOST
function pingHost(){
    //$ping = "ping -n 1 -w 115.254.48.173";
	$ping = "ping 115.254.48.173";
	$str = exec($ping, $input, $result);
	if ($result == 0){
	echo "SYNCHRONIZING DATA: "."<img src=\"../on.gif\">";
	echo "<br />";
	echo "DO NOT CLOSE THE BROWSER UNTILL ALL DATA IS SYNCHRONIZED";
		}else{
	echo "SERVER IS DOWN: "."<img src=\"../off.gif\">";
	echo "<br />";
	echo "Please Try After Some Time Or Contact Administrator: ";
	exit;
    }
}
echo pingHost();

############################## To check Ping Request From Server ##################################
?>
<?php
$dbh1 = mysql_connect('115.254.48.173','root',''); 
if (!$dbh1) {
    die('Could not connect to server: ' . mysql_error());
}
$database_server = "sangrah_guwahati";
mysql_select_db($database_server, $dbh1);


?>


<?php 
//SERVER DATA FETCH
echo "<p style='background:#FF9900;'>"."############## Please Do Not Close The Browser Until All Data Is Imported ###############"."</p>";
echo "################## Phase 1 :: Fetching Data for Category Import From Server #############################";
echo "<br />";
$curr_date = date("Y-m-d");
 //For CATEGORY CRMENTITY
 $phase1_server_crmentity = "SELECT * FROM ".$database_server.".vtiger_crmentity WHERE setype = 'Category' AND 
DATE_FORMAT(createdtime,'%Y-%m-%d') = '".$curr_date."' ";
 $result_phase1_server = mysql_query($phase1_server_crmentity)  or  die("Line No".__LINE__."   ". mysql_error());
 //For BARCODE  CRMENTITY
 $phase1_server_crmentity_barcode = "SELECT * FROM ".$database_server.".vtiger_crmentity WHERE setype = 'Barcode' AND 
DATE_FORMAT(createdtime,'%Y-%m-%d') = '".$curr_date."' ";
 $result_phase1_server_crm_barcode = mysql_query($phase1_server_crmentity_barcode)  or  die("Line No".__LINE__."   ". mysql_error());
  //For PRODUCTS  CRMENTITY
  $phase1_server_crmentity_products = "SELECT * FROM ".$database_server.".vtiger_crmentity WHERE setype = 'Products' AND 
DATE_FORMAT(createdtime,'%Y-%m-%d') = '".$curr_date."' ";
 $result_phase1_server_crm_products = mysql_query($phase1_server_crmentity_products)  or  die("Line No".__LINE__."   ". mysql_error());
  
  $row_phase1_server_crm_products = array();

while($row_phase1_server_crm_products[] = mysql_fetch_assoc($result_phase1_server_crm_products));
array_pop($row_phase1_server_crm_products);
  
$phase1_server_barcode = "SELECT ".$database_server.".vtiger_barcode.* FROM ".$database_server.".vtiger_barcode,".$database_server.".vtiger_crmentity WHERE vtiger_barcode.barcodeid = vtiger_crmentity.crmid AND DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND ".$database_server.".vtiger_crmentity.setype = 'Barcode' ";

$result_phase1_server_barcode = mysql_query($phase1_server_barcode) or  die("Line No".__LINE__."   ". mysql_error());

$row_phase1_server_crm_barcode = array();

while($row_phase1_server_crm_barcode[] = mysql_fetch_assoc($result_phase1_server_crm_barcode));
array_pop($row_phase1_server_crm_barcode);

$row_phase1_server_barcode = array();

while($row_phase1_server_barcode[] = mysql_fetch_assoc($result_phase1_server_barcode));
array_pop($row_phase1_server_barcode);

//Barcode fetch ends
//PRODUCTS FETCH FROM SERVER
$phase1_server_products = "SELECT ".$database_server.".vtiger_products.* FROM ".$database_server.".vtiger_products,".$database_server.".vtiger_crmentity WHERE vtiger_products.productid = vtiger_crmentity.crmid AND DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND ".$database_server.".vtiger_crmentity.setype = 'Products' ";

$result_phase1_server_products = mysql_query($phase1_server_products) or  die("Line No".__LINE__."   ". mysql_error());

$row_phase1_server_products = array();
while($row_phase1_server_products[] = mysql_fetch_assoc($result_phase1_server_products));
array_pop($row_phase1_server_products);
//PRODUCTS FETCH FROM SERVER ENDS
//vtiger_warehouse_stock Data fetch from server
$phase1_server_ware_store = "SELECT  ".$database_server.".vtiger_warehouse_stock.* FROM vtiger_warehouse_stock,vtiger_warehousestore_inventorytransaction WHERE vtiger_warehousestore_inventorytransaction.opening_stock_qty = vtiger_warehousestore_inventorytransaction.closing_stock AND vtiger_warehousestore_inventorytransaction.productid = vtiger_warehouse_stock.productid AND 
vtiger_warehousestore_inventorytransaction.warehousestore_id = vtiger_warehouse_stock.warehouseid AND
DATE_FORMAT(vtiger_warehousestore_inventorytransaction.date,'%Y-%m-%d') = '".$curr_date."' ";

$result_phase1_server_ware_store = mysql_query($phase1_server_ware_store) or  die("Line No".__LINE__."   ". mysql_error());

$row_phase1_server_ware_store = array();
while($row_phase1_server_ware_store[] = mysql_fetch_assoc($result_phase1_server_ware_store));
array_pop($row_phase1_server_ware_store);
//vtiger_warehouse_stock data fetch ends

//FETCH WAREHOUSE TRANSACTION TABLES FOR NEW PRODUCTS OR PRODUCTS RECEIVED FROM PO
$query_fetch_warehouse_tran = "SELECT * FROM ".$database_server.".vtiger_warehousestore_inventorytransaction WHERE opening_stock_qty = closing_stock AND 
DATE_FORMAT(date,'%Y-%m-%d') = '".$curr_date."' ";

$result_warehouse_transaction = mysql_query($query_fetch_warehouse_tran) or  die("Line No".__LINE__."   ". mysql_error());

$row_server_ware_store_trans = array();
while($row_server_ware_store_trans[] = mysql_fetch_assoc($result_warehouse_transaction));
array_pop($row_server_ware_store_trans);

// WAREHOUSE TRANSACTON DATA ENDS

//FETCH INVENTORY TRANSACTION TABLES FOR NEW PRODUCTS OR PRODUCTS RECEIVED FROM PO
$query_fetch_inventorytransaction = "SELECT * FROM ".$database_server.".vtiger_inventorytransaction WHERE opening_stock_qty = closing_stock AND 
DATE_FORMAT(date,'%Y-%m-%d') = '".$curr_date."' ";

$result_inventorytransaction = mysql_query($query_fetch_inventorytransaction) or  die("Line No".__LINE__."   ". mysql_error());

$row_server_inventorytransaction = array();
while($row_server_inventorytransaction[] = mysql_fetch_assoc($result_inventorytransaction));
array_pop($row_server_inventorytransaction);

// INVENTORY TRANSACTON DATA ENDS




$phase1_server_category = "SELECT ".$database_server.".vtiger_category.* FROM ".$database_server.".vtiger_category,".$database_server.".vtiger_crmentity WHERE vtiger_category.categoryid = vtiger_crmentity.crmid AND DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND ".$database_server.".vtiger_crmentity.setype = 'Category' ";

$result_phase1_server_category = mysql_query($phase1_server_category) or  die("Line No".__LINE__."   ". mysql_error());

$row_phase1_server_category = array();
while($row_phase1_server_category[] = mysql_fetch_assoc($result_phase1_server_category));
array_pop($row_phase1_server_category);

$row_phase1_server = array();
while($row_phase1_server[] = mysql_fetch_assoc($result_phase1_server));
array_pop($row_phase1_server);
echo "################## Phase 2 Processing for Category Import #############################";
echo "<br />";

mysql_close($dbh1);
//SERVER CONNECTION CLOSED HERE

//LOCAL CONNECTION OPENED
$dbh2 = mysql_connect('localhost','root','root');
$database_local = "sangrah_guwahati";
if (!$dbh2) {
    die('Could not connect to local: ' . mysql_error());
}
mysql_select_db($database_local, $dbh2);


$phase1 = "SELECT id FROM ".$database_local.".vtiger_crmentity_seq ";
$result_phase1 = mysql_query($phase1)  or  die("Line No".__LINE__."   ". mysql_error());;
$row_phase1 = mysql_fetch_array($result_phase1);
$crmid_local = $row_phase1['id'];

echo "<br />";
//FOR CRMENTITY INSERT
$crmid_crm = $crmid_local;
foreach($row_phase1_server as $key=>$array_crm){
$crmid_crm = $crmid_crm + 1;
 $phase1_insert = "UPDATE ".$database_local.".vtiger_crmentity_seq SET id = ".$crmid_crm." ";
mysql_query($phase1_insert) or  die("Line No".__LINE__."   ". mysql_error());

  $phase1_crmentity_local = "INSERT INTO ".$database_local.".vtiger_crmentity (crmid,smcreatorid,smownerid,modifiedby,setype,description,createdtime,modifiedtime,viewedtime,status,version,presence,deleted ) VALUES
(".$crmid_crm.",
".$array_crm['smcreatorid'].",
".$array_crm['smownerid'].",
".$array_crm['modifiedby'].",
'".$array_crm['setype']."',
'NULL',
'".$array_crm['createdtime']."',
'".$array_crm['modifiedtime']."',
'".$array_crm['viewedtime']."',
'NULL',
".$array_crm['version'].",
".$array_crm['presence'].",
".$array_crm['deleted'].") ";
mysql_query($phase1_crmentity_local) or  die("Line No".__LINE__."   ". mysql_error());

}
//CRMENTITY INSERT ENDS
//FOR CATEGORY INSERT
$crmid_cat = $crmid_local;
foreach($row_phase1_server_category as $key=>$array_cat){
$crmid_cat = $crmid_cat + 1;
$update_local_category_cf = "INSERT INTO  ".$database_local.".vtiger_categorycf(categoryid) VALUES(".$crmid_cat.") ";
mysql_query($update_local_category_cf) or  die("Line No".__LINE__."   ". mysql_error());

$insert_category_local = "INSERT INTO ".$database_local.".vtiger_category (categoryid,categoryname,taxtype,vat,size,color) VALUES
(".$crmid_cat.",'".$array_cat['categoryname']."','".$array_cat['taxtype']."',".$array_cat['vat']." ,'".$array_cat['size']."','".$array_cat['color']."') ";
mysql_query($insert_category_local) or  die("Line No".__LINE__."   ". mysql_error());

}
//CATEGORY INSERT ENDS

echo "##################  Category Import Completed Successfully #############################";
echo "<br />";
echo "################## Phase 3 Processing for Barcode Import #############################";

//Barcode insertion starts for crmentity tables
$phase2 = "SELECT id FROM ".$database_local.".vtiger_crmentity_seq ";
$result_phase2 = mysql_query($phase2)  or  die("Line No".__LINE__."   ". mysql_error());;
$row_phase2 = mysql_fetch_array($result_phase2);
$crmid_local_phase2 = $row_phase2['id'];

$crmid_crm_b = $crmid_local_phase2;
foreach($row_phase1_server_crm_barcode as $key=>$array_crmb){
$crmid_crm_b = $crmid_crm_b + 1;
 $phase1_insert = "UPDATE ".$database_local.".vtiger_crmentity_seq SET id = ".$crmid_crm_b." ";
mysql_query($phase1_insert) or  die("Line No".__LINE__."   ". mysql_error());

  $phase1_crmentity_b_local = "INSERT INTO ".$database_local.".vtiger_crmentity (crmid,smcreatorid,smownerid,modifiedby,setype,description,createdtime,modifiedtime,viewedtime,status,version,presence,deleted ) VALUES
(".$crmid_crm_b.",
".$array_crmb['smcreatorid'].",
".$array_crmb['smownerid'].",
".$array_crmb['modifiedby'].",
'".$array_crmb['setype']."',
'NULL',
'".$array_crmb['createdtime']."',
'".$array_crmb['modifiedtime']."',
'".$array_crmb['viewedtime']."',
'NULL',
".$array_crmb['version'].",
".$array_crmb['presence'].",
".$array_crmb['deleted'].") ";
mysql_query($phase1_crmentity_b_local) or  die("Line No".__LINE__."   ". mysql_error());

}
//Barcode insertion ends for crmentity tables

//Barcode insertion starts for barcode related tables

$crmid_barcode = $crmid_local_phase2;
foreach($row_phase1_server_barcode as $key=>$array_bar){
$crmid_barcode = $crmid_barcode + 1;
$update_local_barcode_cf = "INSERT INTO  ".$database_local.".vtiger_barcodecf (barcodeid,cf_829,cf_830,cf_831,cf_832) VALUES(".$crmid_barcode.",NULL,NULL,NULL,NULL) ";
mysql_query($update_local_barcode_cf) or  die("Line No".__LINE__."   ". mysql_error());

$insert_barcode_local = "INSERT INTO ".$database_local.".vtiger_barcode (barcodeid,companyname,barcode,product_name,price,vat,service,netprice,filename,category,size,barcode_color,barcode_cost,mark_up,barcode_withcform,barcode_withoutcform) VALUES
(".$crmid_barcode.",
'".$array_bar['companyname']."',
'".$array_bar['barcode']."',
'".$array_bar['product_name']."' ,
".$array_bar['price'].",
".$array_bar['vat'].",
NULL,
".$array_bar['netprice'].",
'".$array_bar['filename']."',
".$array_bar['category'].",
'".$array_bar['size']."',
'".$array_bar['barcode_color']."',
".$array_bar['barcode_cost'].",
".$array_bar['mark_up'].",
".$array_bar['barcode_withcform'].",
".$array_bar['barcode_withoutcform']."
) ";
mysql_query($insert_barcode_local) or  die("Line No".__LINE__."   ". mysql_error());

}
//Barcode insertion ends for barcode related tables
echo "<br />";
echo "################## Barcode Imported Successfully #############################";
echo "<br />";
//Products insertion starts for crmentity tables
$phase3 = "SELECT id FROM ".$database_local.".vtiger_crmentity_seq ";
$result_phase3 = mysql_query($phase3)  or  die("Line No".__LINE__."   ". mysql_error());;
$row_phase3 = mysql_fetch_array($result_phase3);
$crmid_local_phase3 = $row_phase3['id'];

$crmid_crm_product = $crmid_local_phase3;
foreach($row_phase1_server_crm_products as $key=>$array_crmb){
$crmid_crm_product = $crmid_crm_product + 1;
 $phase1_insert = "UPDATE ".$database_local.".vtiger_crmentity_seq SET id = ".$crmid_crm_product." ";
mysql_query($phase1_insert) or  die("Line No".__LINE__."   ". mysql_error());

  $phase1_crmentity_pro_local = "INSERT INTO ".$database_local.".vtiger_crmentity (crmid,smcreatorid,smownerid,modifiedby,setype,description,createdtime,modifiedtime,viewedtime,status,version,presence,deleted ) VALUES
(".$crmid_crm_product.",
".$array_crmb['smcreatorid'].",
".$array_crmb['smownerid'].",
".$array_crmb['modifiedby'].",
'".$array_crmb['setype']."',
NULL,
'".$array_crmb['createdtime']."',
'".$array_crmb['modifiedtime']."',
'".$array_crmb['viewedtime']."',
NULL,
".$array_crmb['version'].",
".$array_crmb['presence'].",
".$array_crmb['deleted'].") ";
mysql_query($phase1_crmentity_pro_local) or  die("Line No".__LINE__."   ". mysql_error());

}
//Products insertion ends for crmentity tables

//Products insertion starts for Product related tables
echo "<br />";
echo "################## Phase 4 Processing for Products #############################";

$crmid_products = $crmid_local_phase3;
foreach($row_phase1_server_products as $key=>$array_pro){
$crmid_products = $crmid_products + 1;

  $insert_product_local = "INSERT INTO ".$database_local.".vtiger_products (productid,product_no,productname,barcode,warehouse_id,productcode,productcategory,manufacturer,qty_per_unit,cost,unit_price,discount,netprice,vat,service,frequency,weight,pack_size,sales_start_date,sales_end_date,start_date,expiry_date,cost_factor,commissionrate,commissionmethod,discontinued,usageunit,handler,reorderlevel,website,taxclass,mfr_part_no,vendor_part_no,serialno,qtyinstock,productsheet,qtyindemand,glacct,vendor_id,imagename,currency_id,product_markup,product_withcform,product_withoutcform) VALUES
(".$crmid_products.",
'".$array_pro['product_no']."',
'".$array_pro['productname']."',
'".$array_pro['barcode']."' ,
NULL,NULL,
'".$array_pro['productcategory']."',
NULL,
'".$array_pro['qty_per_unit']."',
'".$array_pro['cost']."',
'".$array_pro['unit_price']."',
'".$array_pro['discount']."',
".$array_pro['netprice'].",
".$array_pro['vat'].",
NULL,
'".$array_pro['frequency']."' ,
NULL,
NULL,
NULL,NULL,NULL,NULL,NULL,NULL,NULL,
".$array_pro['discontinued'].",
'".$array_pro['usageunit']."',
NULL,
".$array_pro['reorderlevel'].",
NULL,NULL,NULL,NULL,NULL,
'".$array_pro['qtyinstock']."',
NULL,NULL,NULL,NULL,NULL,
".$array_pro['currency_id'].",
'".$array_pro['product_markup']."',
'".$array_pro['product_withcform']."',
'".$array_pro['product_withoutcform']."'
) ";
mysql_query($insert_product_local) or  die("Line No".__LINE__."   ". mysql_error());

$update_local_product_cf = "INSERT INTO  ".$database_local.".vtiger_productcf (productid) VALUES(".$crmid_products.") ";
mysql_query($update_local_product_cf) or  die("Line No".__LINE__."   ". mysql_error());

}
//Products insertion ends for products related tables
//Products insertion starts for crmentity tables
$crmid_products_stock = $crmid_local_phase3;
$crmid_products_stock = $crmid_products_stock + 1;
//vtiger_warehouse_stock data table insertion in local 
$temp = 0;
$i=0;
foreach($row_phase1_server_ware_store as $key=>$array_warehouse){
     if($i == 0){
        $temp = $array_warehouse['productid'];
	    $insert_in_local_warehouse = "INSERT INTO ".$database_local.".vtiger_warehouse_stock(warehousestockid,warehouseid,productid,qty,reorder) VALUES
   (NULL,".$array_warehouse['warehouseid'].",".$crmid_products_stock.",".$array_warehouse['qty'].",NULL)";
   
   mysql_query($insert_in_local_warehouse) or  die("Line No".__LINE__."   ". mysql_error());
   $i++;
	   } else if($temp == $array_warehouse['productid']){
         
	   $insert_in_local_warehouse = "INSERT INTO ".$database_local.".vtiger_warehouse_stock(warehousestockid,warehouseid,productid,qty,reorder) VALUES
	   (NULL,".$array_warehouse['warehouseid'].",".$crmid_products_stock.",".$array_warehouse['qty'].",NULL)";
	   
	   mysql_query($insert_in_local_warehouse) or  die("Line No".__LINE__."   ". mysql_error());
      
    } else {
	 $i=0;
	 $crmid_products_stock = $crmid_products_stock + 1;
	 $insert_in_local_warehouse = "INSERT INTO ".$database_local.".vtiger_warehouse_stock(warehousestockid,warehouseid,productid,qty,reorder) VALUES
	   (NULL,".$array_warehouse['warehouseid'].",".$crmid_products_stock.",".$array_warehouse['qty'].",NULL)";
	   
	   mysql_query($insert_in_local_warehouse) or  die("Line No".__LINE__."   ". mysql_error());
	 
	
	 
	}
	
   // Also update vtiger_modentity_num table for Product
   $update_mod_num = "UPDATE ".$database_local.".vtiger_modentity_num SET cur_id = (cur_id + 1) WHERE prefix = 'PRO'  ";
    mysql_query($update_mod_num) or  die("Line No".__LINE__."   ". mysql_error());
 

}
//vtiger_warehouse_stock data table insertion in local ends

//TRANSATION TABLE ENTERIES FOR WAREHOUSE STORE
$crmid_tran_stock = $crmid_local_phase3;
$crmid_tran_stock = $crmid_tran_stock + 1;
$temp_tran = 0;
$j=0;
foreach($row_server_ware_store_trans as $key=>$array_warehouse_trans){

 if($j == 0){
        $temp_tran = $array_warehouse_trans['productid'];
		
	    $insert_warehouse_transaction = "INSERT INTO ".$database_local.".vtiger_warehousestore_inventorytransaction   (warehousestore_transaction_id,date,warehousestore_id,barcode,productid,product_name,opening_stock_qty,opening_cost,markup_per,markup_amt,poid,purchase_qty,purchase_cost,
	  cstwithcform_per,cstwithcform_amt,cstwithoutcform_per,cstwithoutcform_amt,	  invoice_id,invoice_no,sales_qty,sales_cost,purchase_return_qty,
	  purchase_return_cost,sales_return_qty,sales_return_cost,adjustment_qty,adjustment_cost,challan_id,challan_no,challan_qty_sent,challan_qty_receive,
	  closing_stock,final_stock,unitprice,vat,discount,vendor_id) VALUES
(NULL,'".$array_warehouse_trans['date']."',
".$array_warehouse_trans['warehousestore_id'].",
'".$array_warehouse_trans['barcode']."',
".$crmid_tran_stock.",
'".$array_warehouse_trans['product_name']."',
".(!empty($array_warehouse_trans['opening_stock_qty']) ? $array_warehouse_trans['opening_stock_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['opening_cost']) ? $array_warehouse_trans['opening_cost'] : 'NULL').",
".$array_warehouse_trans['markup_per'].",
".$array_warehouse_trans['markup_amt'].",
".(!empty($array_warehouse_trans['poid']) ? $array_warehouse_trans['poid'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_qty']) ? $array_warehouse_trans['purchase_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_cost']) ? $array_warehouse_trans['purchase_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['cstwithcform_per']) ? $array_warehouse_trans['cstwithcform_per'] : 'NULL').",
".$array_warehouse_trans['cstwithcform_amt'].",
".(!empty($array_warehouse_trans['cstwithoutcform_per']) ? $array_warehouse_trans['cstwithoutcform_per'] : 'NULL').",
".$array_warehouse_trans['cstwithoutcform_amt'].",
".(!empty($array_warehouse_trans['invoice_id']) ? $array_warehouse_trans['invoice_id'] : 'NULL').",
".(!empty($array_warehouse_trans['invoice_no']) ? $array_warehouse_trans['invoice_no'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_qty']) ? $array_warehouse_trans['sales_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_cost']) ? $array_warehouse_trans['sales_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_return_qty']) ? $array_warehouse_trans['purchase_return_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_return_cost']) ? $array_warehouse_trans['purchase_return_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_return_qty']) ? $array_warehouse_trans['sales_return_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_return_cost']) ? $array_warehouse_trans['sales_return_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['adjustment_qty']) ? $array_warehouse_trans['adjustment_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['adjustment_cost']) ? $array_warehouse_trans['adjustment_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['challan_id']) ? $array_warehouse_trans['challan_id'] : 'NULL').",
".(!empty($array_warehouse_trans['challan_no']) ? $array_warehouse_trans['challan_no'] : 'NULL').",
".$array_warehouse_trans['challan_qty_sent'].",
".$array_warehouse_trans['challan_qty_receive'].",
".(!empty($array_warehouse_trans['closing_stock']) ? $array_warehouse_trans['closing_stock'] : 'NULL').",
".(!empty($array_warehouse_trans['final_stock']) ? $array_warehouse_trans['final_stock'] : 'NULL').",
".(!empty($array_warehouse_trans['unitprice']) ? $array_warehouse_trans['unitprice'] : 'NULL').",
".(!empty($array_warehouse_trans['vat']) ? $array_warehouse_trans['vat'] : 'NULL')." ,
".(!empty($array_warehouse_trans['discount']) ? $array_warehouse_trans['discount'] : 'NULL')." ,
".(!empty($array_warehouse_trans['vendor_id']) ? $array_warehouse_trans['vendor_id'] : 'NULL')."
)";
   
   mysql_query($insert_warehouse_transaction) or  die("Line No".__LINE__."   ". mysql_error());
   $j++;
	   } else if($temp_tran == $array_warehouse_trans['productid']){
         
	     $insert_warehouse_transaction = "INSERT INTO ".$database_local.".vtiger_warehousestore_inventorytransaction   (warehousestore_transaction_id,date,warehousestore_id,barcode,productid,product_name,opening_stock_qty,opening_cost,markup_per,markup_amt,poid,purchase_qty,purchase_cost,cstwithcform_per,cstwithcform_amt,cstwithoutcform_per,cstwithoutcform_amt,invoice_id,invoice_no,sales_qty,sales_cost,purchase_return_qty,purchase_return_cost,sales_return_qty,sales_return_cost,adjustment_qty,adjustment_cost,challan_id,challan_no,challan_qty_sent,challan_qty_receive,closing_stock,final_stock,unitprice,vat,discount,vendor_id) VALUES
(NULL,'".$array_warehouse_trans['date']."',
".$array_warehouse_trans['warehousestore_id'].",
'".$array_warehouse_trans['barcode']."',
".$crmid_tran_stock.",
'".$array_warehouse_trans['product_name']."',
".(!empty($array_warehouse_trans['opening_stock_qty']) ? $array_warehouse_trans['opening_stock_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['opening_cost']) ? $array_warehouse_trans['opening_cost'] : 'NULL').",
".$array_warehouse_trans['markup_per'].",
".$array_warehouse_trans['markup_amt'].",
".(!empty($array_warehouse_trans['poid']) ? $array_warehouse_trans['poid'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_qty']) ? $array_warehouse_trans['purchase_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_cost']) ? $array_warehouse_trans['purchase_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['cstwithcform_per']) ? $array_warehouse_trans['cstwithcform_per'] : 'NULL').",
".$array_warehouse_trans['cstwithcform_amt'].",
".(!empty($array_warehouse_trans['cstwithoutcform_per']) ? $array_warehouse_trans['cstwithoutcform_per'] : 'NULL').",
".$array_warehouse_trans['cstwithoutcform_amt'].",
".(!empty($array_warehouse_trans['invoice_id']) ? $array_warehouse_trans['invoice_id'] : 'NULL').",
".(!empty($array_warehouse_trans['invoice_no']) ? $array_warehouse_trans['invoice_no'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_qty']) ? $array_warehouse_trans['sales_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_cost']) ? $array_warehouse_trans['sales_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_return_qty']) ? $array_warehouse_trans['purchase_return_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_return_cost']) ? $array_warehouse_trans['purchase_return_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_return_qty']) ? $array_warehouse_trans['sales_return_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_return_cost']) ? $array_warehouse_trans['sales_return_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['adjustment_qty']) ? $array_warehouse_trans['adjustment_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['adjustment_cost']) ? $array_warehouse_trans['adjustment_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['challan_id']) ? $array_warehouse_trans['challan_id'] : 'NULL').",
".(!empty($array_warehouse_trans['challan_no']) ? $array_warehouse_trans['challan_no'] : 'NULL').",
".$array_warehouse_trans['challan_qty_sent'].",
".$array_warehouse_trans['challan_qty_receive'].",
".(!empty($array_warehouse_trans['closing_stock']) ? $array_warehouse_trans['closing_stock'] : 'NULL').",
".(!empty($array_warehouse_trans['final_stock']) ? $array_warehouse_trans['final_stock'] : 'NULL').",
".(!empty($array_warehouse_trans['unitprice']) ? $array_warehouse_trans['unitprice'] : 'NULL').",
".(!empty($array_warehouse_trans['vat']) ? $array_warehouse_trans['vat'] : 'NULL')." ,
".(!empty($array_warehouse_trans['discount']) ? $array_warehouse_trans['discount'] : 'NULL')." ,
".(!empty($array_warehouse_trans['vendor_id']) ? $array_warehouse_trans['vendor_id'] : 'NULL')."
)";
   
	   
	   mysql_query($insert_warehouse_transaction) or  die("Line No".__LINE__."   ". mysql_error());
      
    }else {
	 $j=0;
	 $crmid_tran_stock = $crmid_tran_stock + 1;
	$insert_warehouse_transaction = "INSERT INTO ".$database_local.".vtiger_warehousestore_inventorytransaction 
	(warehousestore_transaction_id,date,warehousestore_id,barcode,productid,product_name,opening_stock_qty,opening_cost,markup_per,markup_amt,poid,purchase_qty,
	purchase_cost,cstwithcform_per,cstwithcform_amt,cstwithoutcform_per,cstwithoutcform_amt,invoice_id,invoice_no,sales_qty,sales_cost,purchase_return_qty,purchase_return_cost,sales_return_qty,sales_return_cost,adjustment_qty,adjustment_cost,challan_id,challan_no,challan_qty_sent,challan_qty_receive,closing_stock,final_stock,unitprice,vat,discount,vendor_id) VALUES
(NULL,'".$array_warehouse_trans['date']."',
".$array_warehouse_trans['warehousestore_id'].",
'".$array_warehouse_trans['barcode']."',
".$crmid_tran_stock.",
'".$array_warehouse_trans['product_name']."',
".(!empty($array_warehouse_trans['opening_stock_qty']) ? $array_warehouse_trans['opening_stock_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['opening_cost']) ? $array_warehouse_trans['opening_cost'] : 'NULL').",
".$array_warehouse_trans['markup_per'].",
".$array_warehouse_trans['markup_amt'].",
".(!empty($array_warehouse_trans['poid']) ? $array_warehouse_trans['poid'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_qty']) ? $array_warehouse_trans['purchase_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_cost']) ? $array_warehouse_trans['purchase_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['cstwithcform_per']) ? $array_warehouse_trans['cstwithcform_per'] : 'NULL').",
".$array_warehouse_trans['cstwithcform_amt'].",
".(!empty($array_warehouse_trans['cstwithoutcform_per']) ? $array_warehouse_trans['cstwithoutcform_per'] : 'NULL').",
".$array_warehouse_trans['cstwithoutcform_amt'].",
".(!empty($array_warehouse_trans['invoice_id']) ? $array_warehouse_trans['invoice_id'] : 'NULL').",
'".(!empty($array_warehouse_trans['invoice_no']) ? $array_warehouse_trans['invoice_no'] : 'NULL')."',
".(!empty($array_warehouse_trans['sales_qty']) ? $array_warehouse_trans['sales_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_cost']) ? $array_warehouse_trans['sales_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_return_qty']) ? $array_warehouse_trans['purchase_return_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['purchase_return_cost']) ? $array_warehouse_trans['purchase_return_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_return_qty']) ? $array_warehouse_trans['sales_return_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['sales_return_cost']) ? $array_warehouse_trans['sales_return_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['adjustment_qty']) ? $array_warehouse_trans['adjustment_qty'] : 'NULL').",
".(!empty($array_warehouse_trans['adjustment_cost']) ? $array_warehouse_trans['adjustment_cost'] : 'NULL').",
".(!empty($array_warehouse_trans['challan_id']) ? $array_warehouse_trans['challan_id'] : 'NULL').",
".(!empty($array_warehouse_trans['challan_no']) ? $array_warehouse_trans['challan_no'] : 'NULL').",
".$array_warehouse_trans['challan_qty_sent'].",
".$array_warehouse_trans['challan_qty_receive'].",
".(!empty($array_warehouse_trans['closing_stock']) ? $array_warehouse_trans['closing_stock'] : 'NULL').",
".(!empty($array_warehouse_trans['final_stock']) ? $array_warehouse_trans['final_stock'] : 'NULL').",
".(!empty($array_warehouse_trans['unitprice']) ? $array_warehouse_trans['unitprice'] : 'NULL').",
".(!empty($array_warehouse_trans['vat']) ? $array_warehouse_trans['vat'] : 'NULL')." ,
".(!empty($array_warehouse_trans['discount']) ? $array_warehouse_trans['discount'] : 'NULL')." ,
".(!empty($array_warehouse_trans['vendor_id']) ? $array_warehouse_trans['vendor_id'] : 'NULL')."
)";

	   mysql_query($insert_warehouse_transaction) or  die("Line No".__LINE__."   ". mysql_error());
	  
	}
 }
//TRANSACTION TABLE ENTERIES ENDS FOR WAREHOUSE STORE

// INVENTORY TRANSACTION TABLE ENTERIES STARTS FOR OPENING CLOSING ALL 
$crmid_inventorytransaction = $crmid_local_phase3;
foreach($row_server_inventorytransaction as $key=>$array_inventorytransaction){
$crmid_inventorytransaction = $crmid_inventorytransaction + 1 ;
 $insert_inventorytransaction = "INSERT INTO ".$database_local.".vtiger_inventorytransaction (transaction_id,date,barcode,productid,product_name,
 opening_stock_qty,opening_stock_WS_qty,opening_cost,markup_per,markup_amt,poid,purchase_qty,purchase_cost,cstwithcform_per,cstwithcform_amt,cstwithoutcform_per,cstwithoutcform_amt,inv_id,invoice_no,sales_qty,store_id,sales_cost,purchase_return_qty,purchase_return_cost,sales_return_qty,sales_return_cost,adjustment_qty,adjustment_cost,challan_id,challan_no,challan_qty_sent,challan_qty_receive,closing_stock,final_stock,discount,unitprice,closing_stock_WS_qty,vat,vendor_id) VALUES
(NULL,
'".$array_inventorytransaction['date']."',
'".$array_inventorytransaction['barcode']."',
".$crmid_inventorytransaction.",
'".$array_inventorytransaction['product_name']."',
".(!empty($array_inventorytransaction['opening_stock_qty']) ? $array_inventorytransaction['opening_stock_qty'] : 'NULL').",
".$array_inventorytransaction['opening_stock_WS_qty'].",
".(!empty($array_inventorytransaction['opening_cost']) ? $array_inventorytransaction['opening_cost'] : 'NULL').",
".$array_inventorytransaction['markup_per'].",
".$array_inventorytransaction['markup_amt'].",
".(!empty($array_inventorytransaction['poid']) ? $array_inventorytransaction['poid'] : 'NULL').",
".(!empty($array_inventorytransaction['purchase_qty']) ? $array_inventorytransaction['purchase_qty'] : 'NULL').",
".(!empty($array_inventorytransaction['purchase_cost']) ? $array_inventorytransaction['purchase_cost'] : 'NULL').",
".(!empty($array_inventorytransaction['cstwithcform_per']) ? $array_inventorytransaction['cstwithcform_per'] : 'NULL').",
".$array_inventorytransaction['cstwithcform_amt'].",
".(!empty($array_inventorytransaction['cstwithoutcform_per']) ? $array_inventorytransaction['cstwithoutcform_per'] : 'NULL').",
".$array_inventorytransaction['cstwithoutcform_amt'].",
".(!empty($array_inventorytransaction['inv_id']) ? $array_inventorytransaction['inv_id'] : 'NULL').",
'".(!empty($array_inventorytransaction['invoice_no']) ? $array_inventorytransaction['invoice_no']  : 'NULL')."',
".(!empty($array_inventorytransaction['sales_qty']) ? $array_inventorytransaction['sales_qty'] : 'NULL').",
".(!empty($array_inventorytransaction['store_id']) ? $array_inventorytransaction['store_id'] : 'NULL').",
".(!empty($array_inventorytransaction['sales_cost']) ? $array_inventorytransaction['sales_cost'] : 'NULL').",
".(!empty($array_inventorytransaction['purchase_return_qty']) ? $array_inventorytransaction['purchase_return_qty'] : 'NULL').",
".(!empty($array_inventorytransaction['purchase_return_cost']) ? $array_inventorytransaction['purchase_return_cost'] : 'NULL').",
".(!empty($array_inventorytransaction['sales_return_qty']) ? $array_inventorytransaction['sales_return_qty'] : 'NULL').",
".(!empty($array_inventorytransaction['sales_return_cost']) ? $array_inventorytransaction['sales_return_cost'] : 'NULL').",
".(!empty($array_inventorytransaction['adjustment_qty']) ? $array_inventorytransaction['adjustment_qty'] : 'NULL').",
".(!empty($array_inventorytransaction['adjustment_cost']) ? $array_inventorytransaction['adjustment_cost'] : 'NULL').",
".(!empty($array_inventorytransaction['challan_id']) ? $array_inventorytransaction['challan_id'] : 'NULL').",
".(!empty($array_inventorytransaction['challan_no']) ? $array_inventorytransaction['challan_no'] : 'NULL').",
".$array_inventorytransaction['challan_qty_sent'].",
".$array_inventorytransaction['challan_qty_receive'].",
".$array_inventorytransaction['closing_stock'].",
".$array_inventorytransaction['final_stock'].",
".(!empty($array_inventorytransaction['discount']) ? $array_inventorytransaction['discount'] : 'NULL').",
".$array_inventorytransaction['unitprice'].",
".$array_inventorytransaction['closing_stock_WS_qty'].",
".(!empty($array_inventorytransaction['vat']) ? $array_inventorytransaction['vat'] : 'NULL')." ,
".(!empty($array_inventorytransaction['vendor_id']) ? $array_inventorytransaction['vendor_id'] : 'NULL')."
)";


 mysql_query($insert_inventorytransaction) or  die("Line No".__LINE__."   ". mysql_error());
}
// INVENTORY TRANSACTION TABLE ENTERIES ENDS FOR OPENING CLOSING ALL  ENDS

echo "################## Products  Imported Successfully #############################";
echo "<br />";
echo pingHost();
echo "<p style= 'background:#66CC33;'>"."############## All Data Imported Successfully Now You Can Close The Browser ###############"."</p>";
mysql_close($dbh2);
?>
