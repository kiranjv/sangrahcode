<?php
error_reporting(1);
//Store1 id hardcoded... NEED TO CHANGE FOR PARTICULAR STORE ID
######################
$STOREID = 3;
$STORENAME = "Store1";
######################

//CHECKING FOR SERVER IS UP OR NOT BY PINGING THE HOST
function pingHost(){
    //$ping = "ping -n 1 -w 115.254.48.173";
	$ping = "ping 115.254.48.173";
	$str = exec($ping, $input, $result);
	if ($result == 0){
	echo "SYNCHRONIZING DATA: "."<img src=\"../on.gif\">";
	echo "<br />";
	echo "DO NOT CLOSE THE BROWSER UNTILL ALL DATA IS SYNCHRONIZED";
		}else{
	echo "SERVER IS DOWN: "."<img src=\"../off.gif\">";
	echo "<br />";
	echo "Please Try After Some Time Or Contact Administrator: ";
	exit;
    }
}
echo pingHost();

############################## To check Ping Request From Server ##################################
?>
<?php
###################################################################################################
###########  SCRIPT FOR SYNCHRONIZING SALES DATA ON SERVER FROM LOCAL   ###########################
###################################################################################################

############ DATABASE NAMES FOR SERVER AND LOCAL  ############
//SERVER DATABASE
$database_server = "sangrah_guwahati";
//LOCAL DATABASE
$database_local = "sangrah_guwahati";
//Prepare dat from local that need to be send on server
// Here first local connection will be open to prepare data from local system 
//LOCAL CONNECTION ESTABLISHMENT
$dblocal = mysql_connect('localhost','root','');
	if (!$dblocal) {
		die('Could not connect to local: ' . mysql_error());
	}
mysql_select_db($database_local, $dblocal);
?>
<?php
########### FETCH crmentity data for invoice creation #####################
echo "<p style='background:#FF9900;'>"."############## Please Do Not Close The Browser Until All Data Is Exported to Server ###############"."</p>";
echo "################## Phase 1 :: Fetching Data for Invoice From Local Terminal #############################";
echo "<br />";
$curr_date = date("Y-m-d");
//For INVOICE /CONTACTS/ CASHRECEIPT CRMENTITY
 $phase1_local_crmentity = "SELECT * FROM ".$database_local.".vtiger_crmentity WHERE (setype = 'Invoice' OR setype = 'Contacts' OR setype = 'Cashreceipt' OR setype = 'SalesReturn')AND DATE_FORMAT(createdtime,'%Y-%m-%d') = '".$curr_date."' ";
 $result_phase1_local_crmentity = mysql_query($phase1_local_crmentity)  or  die("Line No".__LINE__."   ". mysql_error());
 //For Invoice  CRMENTITY

 $row_phase1_local_crmentity = array();
while($row_phase1_local_crmentity[] = mysql_fetch_assoc($result_phase1_local_crmentity));
array_pop($row_phase1_local_crmentity);

//FETCH INVOICE FROM LOCAL TERMINAL 
$phase1_local_invoice = "SELECT ".$database_local.".vtiger_invoice.* FROM ".$database_local.".vtiger_invoice,".$database_local.".vtiger_crmentity WHERE vtiger_invoice.invoiceid = vtiger_crmentity.crmid AND DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND ".$database_local.".vtiger_crmentity.setype = 'Invoice' ";

$result_phase1_local_invoice = mysql_query($phase1_local_invoice) or  die("Line No".__LINE__."   ". mysql_error());

$row_phase1_local_invoice = array();

while($row_phase1_local_invoice[] = mysql_fetch_assoc($result_phase1_local_invoice));
array_pop($row_phase1_local_invoice);

//FETCH INVOICE PRODUCT RELATION TABLE FOR ALL INVOICE
//TO DO NEED TO CHANGE THIS QUERY FOR FETCHING ONLY THE DATA AS PER THE CURRENT DATE

$phase1_local_invoice_product_relation = "SELECT ".$database_local.".vtiger_inventoryproductrel.* FROM vtiger_inventoryproductrel,vtiger_invoice WHERE
vtiger_invoice.invoiceid = vtiger_inventoryproductrel.id";

$result_phase1_local_invoice_relation = mysql_query($phase1_local_invoice_product_relation) or  die("Line No".__LINE__."   ". mysql_error());

$row_phase1_local_invoice_relation = array();

while($row_phase1_local_invoice_relation[] = mysql_fetch_assoc($result_phase1_local_invoice_relation));
array_pop($row_phase1_local_invoice_relation);

//FETCH WAREHOUSE TRANSACTION TABLES FOR NEW PRODUCTS OR PRODUCTS RECEIVED FROM PO
$query_fetch_warehouse_tran = "SELECT * FROM ".$database_local.".vtiger_warehousestore_inventorytransaction WHERE opening_stock_qty != closing_stock AND 
DATE_FORMAT(date,'%Y-%m-%d') = '".$curr_date."'";

$result_warehouse_transaction = mysql_query($query_fetch_warehouse_tran) or  die("Line No".__LINE__."   ". mysql_error());

$row_server_ware_store_trans = array();
while($row_server_ware_store_trans[] = mysql_fetch_assoc($result_warehouse_transaction));
array_pop($row_server_ware_store_trans);

// WAREHOUSE TRANSACTON DATA ENDS
//INVENTORY TRANSACTION TABLE DATA FETCH
 $query_fetch_inventorytransaction = "SELECT * FROM ".$database_local.".vtiger_inventorytransaction WHERE opening_stock_qty != closing_stock AND 
DATE_FORMAT(date,'%Y-%m-%d') = '".$curr_date."' ";

$result_inventorytransaction = mysql_query($query_fetch_inventorytransaction) or  die("Line No".__LINE__."   ". mysql_error());

$row_server_inventorytransaction = array();
while($row_server_inventorytransaction[] = mysql_fetch_assoc($result_inventorytransaction));
array_pop($row_server_inventorytransaction);

//INVENTORY TRANSACTION DATA FETCH ENDS HERE

//FETCH CUSTOMER DATA TO SYNC
$query_fetch_local_contactdetails = "SELECT ".$database_local.".vtiger_contactdetails.* FROM vtiger_contactdetails,vtiger_crmentity WHERE DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND vtiger_crmentity.crmid = vtiger_contactdetails.contactid ";

$result_local_contactdetails = mysql_query($query_fetch_local_contactdetails) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_contactdetails = array();
while($row_local_contactdetails[] = mysql_fetch_assoc($result_local_contactdetails));
array_pop($row_local_contactdetails);

$query_fetch_local_contactaddress = "SELECT ".$database_local.".vtiger_contactaddress.* FROM vtiger_contactaddress,vtiger_crmentity WHERE DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND vtiger_crmentity.crmid = vtiger_contactaddress.contactaddressid ";

$result_local_contactaddress = mysql_query($query_fetch_local_contactaddress) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_contactaddress = array();
while($row_local_contactaddress[] = mysql_fetch_assoc($result_local_contactaddress));
array_pop($row_local_contactaddress);

//NOTE FROM THE ABOVE QUERY WE CAN INSERT THE DATA FOR OTHER TABLES RELATED TO CONTACTS
############################
//TODO
//vtiger_contatscf
//vtiger_customerdetails
############################

//CUSTOMER DATA IS PREPARED
//FETCH CASHRECEIPT DETAILS FROM LOCAL SYSTEM
$query_local_cashreceipt = "SELECT ".$database_local.".vtiger_cashreceipt.* FROM vtiger_cashreceipt,vtiger_crmentity WHERE DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND vtiger_crmentity.crmid = vtiger_cashreceipt.cashreceiptid  ";

$result_local_cashreceipt = mysql_query($query_local_cashreceipt) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_cashreceipt = array();
while($row_local_cashreceipt[] = mysql_fetch_assoc($result_local_cashreceipt));
array_pop($row_local_cashreceipt);

//CASHRECEIPT RELATED DATA FROM vtiger_cashreturndetails TABLE
$query_local_cashreturndetails = "SELECT ".$database_local.".vtiger_cashreturndetails.* FROM vtiger_cashreturndetails,vtiger_crmentity WHERE DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND vtiger_crmentity.crmid = vtiger_cashreturndetails.cashreceiptid  ";

$result_local_cashreturndetails = mysql_query($query_local_cashreturndetails) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_cashreturndetails = array();
while($row_local_cashreturndetails[] = mysql_fetch_assoc($result_local_cashreturndetails));
array_pop($row_local_cashreturndetails);
//CASHRECEIPT DATA PREPARED 

//FETCH DATA FOR SALESRETURN 

$query_local_salesret = "SELECT ".$database_local.".vtiger_salesret.* FROM vtiger_salesret,vtiger_crmentity WHERE DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND vtiger_crmentity.crmid = vtiger_salesret.salesid  ";

$result_local_salesret = mysql_query($query_local_salesret) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_salesret = array();
while($row_local_salesret[] = mysql_fetch_assoc($result_local_salesret));
array_pop($row_local_salesret);

//NOTE vtiger_salesretcf indeividual enteries need to be done at the time of inserting data from server temp tables to main tables

$query_local_salereturn_productdetail = "SELECT ".$database_local.".salereturn_productdetail.* FROM salereturn_productdetail,vtiger_crmentity WHERE DATE_FORMAT(vtiger_crmentity.createdtime,'%Y-%m-%d') = '".$curr_date."' AND vtiger_crmentity.crmid = salereturn_productdetail.salesreturn_id  ";

$result_local_salereturn_productdetail = mysql_query($query_local_salereturn_productdetail) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_salereturn_productdetail = array();
while($row_local_salereturn_productdetail[] = mysql_fetch_assoc($result_local_salereturn_productdetail));
array_pop($row_local_salereturn_productdetail);


//SALES RETURN DATA FETCHED ENDS
//DEBTOR TRANSACTION FETCH DATA

$query_local_debtortransaction = "SELECT ".$database_local.".vtiger_debtortransaction.* FROM vtiger_debtortransaction,vtiger_crmentity WHERE DATE_FORMAT(vtiger_debtortransaction.date,'%Y-%m-%d') = '".$curr_date."' AND vtiger_crmentity.crmid = vtiger_debtortransaction.invid  ";

$result_local_debtortransaction = mysql_query($query_local_debtortransaction) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_debtortransaction = array();
while($row_local_debtortransaction[] = mysql_fetch_assoc($result_local_debtortransaction));
array_pop($row_local_debtortransaction);
//DEBTOR TRANSACTION ENDS HERE

//FOR DELIVERY CHALLAN
//5 tables will be used
//1
$query_local_deliverychallan = "SELECT * FROM  ".$database_local.".vtiger_deliverychallan WHERE DATE_FORMAT(createddate,'%Y-%m-%d') = '".$curr_date."' ";

$result_local_deliverychallan = mysql_query($query_local_deliverychallan) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_deliverychallan = array();
while($row_local_deliverychallan[] = mysql_fetch_assoc($result_local_deliverychallan));
array_pop($row_local_deliverychallan);
//2
$query_local_deliverychallan_trans = "SELECT * FROM  ".$database_local.".vtiger_deliverychallan_transaction WHERE DATE_FORMAT(createddate,'%Y-%m-%d') = '".$curr_date."' AND dc_qty_locked != 0   ";

$result_local_deliverychallan_trans = mysql_query($query_local_deliverychallan_trans) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_deliverychallan_trans = array();
while($row_local_deliverychallan_trans[] = mysql_fetch_assoc($result_local_deliverychallan_trans));
array_pop($row_local_deliverychallan_trans);
//3
$query_local_delivery_products = "SELECT ".$database_local.".vtiger_delivery_products.* FROM vtiger_delivery_products,vtiger_deliverychallan WHERE vtiger_deliverychallan.dcid = vtiger_delivery_products.dcid AND DATE_FORMAT(vtiger_deliverychallan.createddate,'%Y-%m-%d') = '".$curr_date."' AND vtiger_delivery_products.dc_qty_locked != 0  ";

$result_local_delivery_products = mysql_query($query_local_delivery_products) or  die("Line No".__LINE__."   ". mysql_error());
$row_local_delivery_products = array();
while($row_local_delivery_products[] = mysql_fetch_assoc($result_local_delivery_products));
array_pop($row_local_delivery_products);

// FOR DELIVERY CHALLAN ENDS
?>
<?php
//Disconectin the open connection
################################
mysql_close($dblocal);
################################
?>
<?php
// Prior to this we have to close the local terminal connection first 
// Inserting the data on the server for Crmentity and Invoice Tables ---- Temporary Tables Insertion only
// server connection will be open to send date to server 
//SERVER CONNECTION ESTABLISHMENT
$dblserver = mysql_connect('115.254.48.173','root','');
	if (!$dblserver) {
		die('Could not connect to Server: ' . mysql_error());
	}
mysql_select_db($database_server, $dblserver);
?>
<?php
//Here First check if data  to be send is already on the server  in temp tables... 
//If hit counter is Null then Insert the data other wise check for Max three tries 
   $check_server_sync_store_status = "SELECT  *,COUNT(*) AS total FROM ".$database_server.".sync_configuration WHERE DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."'  AND sync_store_id = ".$STOREID."  ";

$result_server_sync_store_status = mysql_query($check_server_sync_store_status);
$row_server_sync_store_status = mysql_fetch_array($result_server_sync_store_status);
if($row_server_sync_store_status['total'] == 0){

echo "Deleting the  previous enteries And inserting the fresh data ";

$q1 = "DELETE FROM ".$database_server.".sync_vtiger_crmentity WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q1) or  die("Line No".__LINE__."   ". mysql_error());
$q2 = "DELETE FROM ".$database_server.".sync_vtiger_invoice WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q2) or  die("Line No".__LINE__."   ". mysql_error());
$q3 = "DELETE FROM ".$database_server.".sync_vtiger_inventoryproductrel WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q3) or  die("Line No".__LINE__."   ". mysql_error());
$q4 = "DELETE FROM ".$database_server.".sync_vtiger_inventorytransaction WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q4) or  die("Line No".__LINE__."   ". mysql_error());
$q5 = "DELETE FROM ".$database_server.".sync_vtiger_warehousestore_inventorytransaction WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q5) or  die("Line No".__LINE__."   ". mysql_error());

$q6 = "DELETE FROM ".$database_server.".sync_configuration WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q6) or  die("Line No".__LINE__."   ". mysql_error());

$q7 = "DELETE FROM ".$database_server.".sync_vtiger_contactaddress WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q7) or  die("Line No".__LINE__."   ". mysql_error());

$q8 = "DELETE FROM ".$database_server.".sync_vtiger_contactdetails WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q8) or  die("Line No".__LINE__."   ". mysql_error());

$q9 = "DELETE FROM ".$database_server.".sync_vtiger_cashreceipt WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q9) or  die("Line No".__LINE__."   ". mysql_error());

$q10 = "DELETE FROM ".$database_server.".sync_vtiger_cashreturndetails WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q10) or  die("Line No".__LINE__."   ". mysql_error());

$q11 = "DELETE FROM ".$database_server.".sync_vtiger_debtortransaction WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q11) or  die("Line No".__LINE__."   ". mysql_error());

$q12 = "DELETE FROM ".$database_server.".sync_vtiger_inventoryproductrel WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q12) or  die("Line No".__LINE__."   ". mysql_error());

$q13 = "DELETE FROM ".$database_server.".sync_salereturn_productdetail WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q13) or  die("Line No".__LINE__."   ". mysql_error());

$q14 = "DELETE FROM ".$database_server.".sync_vtiger_salesret WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q14) or  die("Line No".__LINE__."   ". mysql_error());



//Insert The data As its first time or it was failled Previously
foreach($row_phase1_local_crmentity as $key=>$array_crm){
 

  $phase1_crmentity_server = "INSERT INTO ".$database_server.".sync_vtiger_crmentity (crmid,smcreatorid,smownerid,modifiedby,setype,description,createdtime,modifiedtime,viewedtime,status,version,presence,deleted,sync_store_id,storename,
  sync_date) VALUES
(".$array_crm['crmid'].",
".$array_crm['smcreatorid'].",
".$array_crm['smownerid'].",
".$array_crm['modifiedby'].",
'".$array_crm['setype']."',
NULL,
'".$array_crm['createdtime']."',
'".$array_crm['modifiedtime']."',
'".$array_crm['viewedtime']."',
NULL,
".$array_crm['version'].",
".$array_crm['presence'].",
".$array_crm['deleted'].",
".$STOREID.",
'".$STORENAME."',
NOW() )";
mysql_query($phase1_crmentity_server) or  die("Line No".__LINE__."   ". mysql_error());

}
//DATA FOR SYNC_CRMENTITY INSERTED SUCCESSFULLY
//Insertion for Invoice data
foreach($row_phase1_local_invoice as $key=>$array_invoice){
 //$phase1_insert = "UPDATE ".$database_local.".vtiger_crmentity_seq SET id = ".$crmid_crm." ";
//mysql_query($phase1_insert) or  die("Line No".__LINE__."   ". mysql_error());

  $phase1_invoice_server = "INSERT IGNORE INTO ".$database_server.".sync_vtiger_invoice (invoiceid,subject,salesorderid,customerno,contactid,notes,invoicedate,duedate,invoiceterms,type,adjustment,salescommission,exciseduty,subtotal,total,taxtype,discount_percent,discount_amount,s_h_amount,shipping,accountid,terms_conditions,purchaseorder,invoicestatus,invoice_no,currency_id,conversion_rate,customername,mobile,salesorderno,email,cash,credit,card,bankname,chq_date,cheque_no,cheque_amt,storeid,sync_store_id,storename,sync_date) VALUES
(".$array_invoice['invoiceid'].",
".(!empty($array_invoice['subject']) ? $array_invoice['subject'] : 'NULL').",
".(!empty($array_invoice['salesorderid']) ? $array_invoice['salesorderid'] : 'NULL').",
".(!empty($array_invoice['customerno']) ? $array_invoice['customerno'] : 'NULL').",
".(!empty($array_invoice['contactid']) ? $array_invoice['contactid'] : 'NULL').",
".(!empty($array_invoice['notes']) ? $array_invoice['notes'] : 'NULL').",
'".$array_invoice['invoicedate']."',
".(!empty($array_invoice['duedate']) ? $array_invoice['duedate'] : 'NULL').",
".(!empty($array_invoice['invoiceterms']) ? $array_invoice['invoiceterms'] : 'NULL').",
".(!empty($array_invoice['type']) ? $array_invoice['type'] : 'NULL').",
".$array_invoice['adjustment'].",
".(!empty($array_invoice['salescommission']) ? $array_invoice['salescommission'] : 'NULL').",
".(!empty($array_invoice['exciseduty']) ? $array_invoice['exciseduty'] : 'NULL').",
".$array_invoice['subtotal'].",
".$array_invoice['total'].",
".(!empty($array_invoice['taxtype']) ? $array_invoice['taxtype'] : 'NULL').",
".(!empty($array_invoice['discount_percent']) ? $array_invoice['discount_percent'] : 'NULL').",
'".$array_invoice['discount_amount']."',
".(!empty($array_invoice['s_h_amount']) ? $array_invoice['s_h_amount'] : 'NULL').",
".(!empty($array_invoice['shipping']) ? $array_invoice['shipping'] : 'NULL').",
".(!empty($array_invoice['accountid']) ? $array_invoice['accountid'] : 'NULL').",
".(!empty($array_invoice['terms_conditions']) ? $array_invoice['terms_conditions'] : 'NULL').",
".(!empty($array_invoice['purchaseorder']) ? $array_invoice['purchaseorder'] : 'NULL').",
'".$array_invoice['invoicestatus']."',
'".$array_invoice['invoice_no']."',
".$array_invoice['currency_id'].",
".$array_invoice['conversion_rate'].",
'".(!empty($array_invoice['customername']) ? $array_invoice['customername'] : '')."',
'".(!empty($array_invoice['mobile']) ? $array_invoice['mobile'] : '')."',
'".(!empty($array_invoice['salesorderno']) ? $array_invoice['salesorderno'] : '')."',
'".(!empty($array_invoice['email']) ? $array_invoice['email'] : '')."',
".$array_invoice['cash'].",
".$array_invoice['credit'].",
".$array_invoice['card'].",
'".(!empty($array_invoice['bankname']) ? $array_invoice['bankname'] : '')."',
'".$array_invoice['chq_date']."',
'".(!empty($array_invoice['cheque_no']) ? $array_invoice['cheque_no'] : '')."',
".$array_invoice['cheque_amt'].",
".$array_invoice['storeid'].",
".$STOREID.",
'".$STORENAME."',
NOW() )";
mysql_query($phase1_invoice_server) or  die("Line No".__LINE__."   ". mysql_error());

}

// INSERT INTO SERVER INVOICE PRODUCT RELATION TABLE
foreach($row_phase1_local_invoice_relation as $key=>$array_inv_relation){
   $insert_server_invoice_relation = "INSERT INTO  ".$database_server.".sync_vtiger_inventoryproductrel   (id,productid,sequence_no,qtyinstock,quantity,listprice,discount_percent,discount_amount,comment,description,incrementondel,lineitem_id,tax1,tax2,tax3,vat,taxamount,withcform,service,netprice,tax4,tax5,tax6,sync_store_id,storename,sync_date) VALUES 
(".$array_inv_relation['id'].",
".$array_inv_relation['productid'].",
".$array_inv_relation['sequence_no'].",
'".(!empty($array_inv_relation['qtyinstock']) ? $array_inv_relation['qtyinstock'] : 'NULL')."',
".$array_inv_relation['quantity'].",
".$array_inv_relation['listprice'].",
'".(!empty($array_inv_relation['discount_percent']) ? $array_inv_relation['discount_percent'] : 'NULL')."',
".$array_inv_relation['discount_amount'].",
'".(!empty($array_inv_relation['comment']) ? $array_inv_relation['comment'] : 'NULL')."',
'".(!empty($array_inv_relation['description']) ? $array_inv_relation['description'] : 'NULL')."',
".$array_inv_relation['incrementondel'].",
".$array_inv_relation['lineitem_id'].",
'".(!empty($array_inv_relation['tax1']) ? $array_inv_relation['tax1'] : 'NULL')."',
'".(!empty($array_inv_relation['tax2']) ? $array_inv_relation['tax2'] : 'NULL')."',
'".(!empty($array_inv_relation['tax3']) ? $array_inv_relation['tax3'] : 'NULL')."',
".$array_inv_relation['vat'].",
".$array_inv_relation['taxamount'].",
'".(!empty($array_inv_relation['withcform']) ? $array_inv_relation['withcform'] : 'NULL')."',
'".(!empty($array_inv_relation['service']) ? $array_inv_relation['service'] : 'NULL')."',
".$array_inv_relation['netprice'].",
'".(!empty($array_inv_relation['tax4']) ? $array_inv_relation['tax4'] : 'NULL')."',
'".(!empty($array_inv_relation['tax5']) ? $array_inv_relation['tax5'] : 'NULL')."',
'".(!empty($array_inv_relation['tax6']) ? $array_inv_relation['tax6'] : 'NULL')."',
".$STOREID.",
'".$STORENAME."',
NOW()
) ";
}
mysql_query($insert_server_invoice_relation) or  die("Line No".__LINE__."   ". mysql_error());

// INSERTION ENDS FOR PRODUCTS RELATION TABLE
//INSERTION IN vtiger_warehousestore_inventorytransaction TRANSACTION TABLE
foreach($row_server_ware_store_trans as $key=>$array_warehouse_trans){

	$insert_warehouse_transaction = "INSERT INTO ".$database_server.".sync_vtiger_warehousestore_inventorytransaction   (warehousestore_transaction_id,date,warehousestore_id,barcode,productid,product_name,opening_stock_qty,opening_cost,markup_per,markup_amt,poid,purchase_qty,purchase_cost,
	  cstwithcform_per,cstwithcform_amt,cstwithoutcform_per,cstwithoutcform_amt,	  invoice_id,invoice_no,sales_qty,sales_cost,purchase_return_qty,purchase_return_cost,sales_return_qty,sales_return_cost,adjustment_qty,adjustment_cost,challan_id,challan_no,challan_qty_sent,challan_qty_receive,closing_stock,final_stock,unitprice,vat,discount,vendor_id,sync_store_id,storename,sync_date) VALUES
	(".$array_warehouse_trans['warehousestore_transaction_id'].",
	'".$array_warehouse_trans['date']."',
	".$array_warehouse_trans['warehousestore_id'].",
	'".$array_warehouse_trans['barcode']."',
	".$array_warehouse_trans['productid'].",
	'".$array_warehouse_trans['product_name']."',
	".(!empty($array_warehouse_trans['opening_stock_qty']) ? $array_warehouse_trans['opening_stock_qty'] : 'NULL').",
	".(!empty($array_warehouse_trans['opening_cost']) ? $array_warehouse_trans['opening_cost'] : 'NULL').",
	".$array_warehouse_trans['markup_per'].",
	".$array_warehouse_trans['markup_amt'].",
	".(!empty($array_warehouse_trans['poid']) ? $array_warehouse_trans['poid'] : 'NULL').",
	".(!empty($array_warehouse_trans['purchase_qty']) ? $array_warehouse_trans['purchase_qty'] : 'NULL').",
	".(!empty($array_warehouse_trans['purchase_cost']) ? $array_warehouse_trans['purchase_cost'] : 'NULL').",
	".$array_warehouse_trans['cstwithcform_per'].",
	".$array_warehouse_trans['cstwithcform_amt'].",
	".$array_warehouse_trans['cstwithoutcform_per'].",
	".$array_warehouse_trans['cstwithoutcform_amt'].",
	".(!empty($array_warehouse_trans['invoice_id']) ? $array_warehouse_trans['invoice_id'] : 'NULL').",
	'".(!empty($array_warehouse_trans['invoice_no']) ? $array_warehouse_trans['invoice_no'] : 'NULL')."',
	".(!empty($array_warehouse_trans['sales_qty']) ? $array_warehouse_trans['sales_qty'] : 'NULL').",
	".(!empty($array_warehouse_trans['sales_cost']) ? $array_warehouse_trans['sales_cost'] : 'NULL').",
	".(!empty($array_warehouse_trans['purchase_return_qty']) ? $array_warehouse_trans['purchase_return_qty'] : 'NULL').",
	".(!empty($array_warehouse_trans['purchase_return_cost']) ? $array_warehouse_trans['purchase_return_cost'] : 'NULL').",
	".(!empty($array_warehouse_trans['sales_return_qty']) ? $array_warehouse_trans['sales_return_qty'] : 'NULL').",
	".(!empty($array_warehouse_trans['sales_return_cost']) ? $array_warehouse_trans['sales_return_cost'] : 'NULL').",
	".(!empty($array_warehouse_trans['adjustment_qty']) ? $array_warehouse_trans['adjustment_qty'] : 'NULL').",
	".(!empty($array_warehouse_trans['adjustment_cost']) ? $array_warehouse_trans['adjustment_cost'] : 'NULL').",
	".(!empty($array_warehouse_trans['challan_id']) ? $array_warehouse_trans['challan_id'] : 'NULL').",
	".(!empty($array_warehouse_trans['challan_no']) ? $array_warehouse_trans['challan_no'] : 'NULL').",
	".$array_warehouse_trans['challan_qty_sent'].",
	".$array_warehouse_trans['challan_qty_receive'].",
	".(!empty($array_warehouse_trans['closing_stock']) ? $array_warehouse_trans['closing_stock'] : 'NULL').",
	".(!empty($array_warehouse_trans['final_stock']) ? $array_warehouse_trans['final_stock'] : 'NULL').",
	".(!empty($array_warehouse_trans['unitprice']) ? $array_warehouse_trans['unitprice'] : 'NULL').",
	".(!empty($array_warehouse_trans['vat']) ? $array_warehouse_trans['vat'] : 'NULL')." ,
	".(!empty($array_warehouse_trans['discount']) ? $array_warehouse_trans['discount'] : 'NULL')." ,
	".(!empty($array_warehouse_trans['vendor_id']) ? $array_warehouse_trans['vendor_id'] : 'NULL').",
	".$STOREID.",
	'".$STORENAME."',
	NOW()
	) ";
      
   mysql_query($insert_warehouse_transaction) or  die("Line No".__LINE__."   ". mysql_error());
  }
//INSERTION FOR TRANSATION TABLES END HERE
//INSERTION FOR vtiger_inventorytransaction TRANSACTION STARTED
foreach($row_server_inventorytransaction as $key=>$array_inventorytransaction){

 $insert_inventorytransaction = "INSERT INTO ".$database_server.".sync_vtiger_inventorytransaction (transaction_id,date,barcode,productid,product_name,opening_stock_qty,opening_stock_WS_qty,opening_cost,markup_per,markup_amt,poid,purchase_qty,purchase_cost,inv_id,invoice_no,sales_qty,store_id,sales_cost,purchase_return_qty,purchase_return_cost,sales_return_qty,sales_return_cost,adjustment_qty,adjustment_cost,challan_id,challan_no,challan_qty_sent,challan_qty_receive,closing_stock,final_stock,discount,unitprice,closing_stock_WS_qty,vat,vendor_id,sync_store_id,storename,sync_date) VALUES
	(".$array_inventorytransaction['transaction_id'].",
	'".$array_inventorytransaction['date']."',
	'".$array_inventorytransaction['barcode']."',
	".$array_inventorytransaction['productid'].",
	'".$array_inventorytransaction['product_name']."',
	".(!empty($array_inventorytransaction['opening_stock_qty']) ? $array_inventorytransaction['opening_stock_qty'] : 'NULL').",
	".$array_inventorytransaction['opening_stock_WS_qty'].",
	".(!empty($array_inventorytransaction['opening_cost']) ? $array_inventorytransaction['opening_cost'] : 'NULL').",
	".$array_inventorytransaction['markup_per'].",
	".$array_inventorytransaction['markup_amt'].",
	".(!empty($array_inventorytransaction['poid']) ? $array_inventorytransaction['poid'] : 'NULL').",
	".(!empty($array_inventorytransaction['purchase_qty']) ? $array_inventorytransaction['purchase_qty'] : 'NULL').",
	".(!empty($array_inventorytransaction['purchase_cost']) ? $array_inventorytransaction['purchase_cost'] : 'NULL').",
	".(!empty($array_inventorytransaction['inv_id']) ? $array_inventorytransaction['inv_id'] : 'NULL').",
	'".(!empty($array_inventorytransaction['invoice_no']) ? $array_inventorytransaction['invoice_no']  : 'NULL')."',
	".(!empty($array_inventorytransaction['sales_qty']) ? $array_inventorytransaction['sales_qty'] : 'NULL').",
	".(!empty($array_inventorytransaction['store_id']) ? $array_inventorytransaction['store_id'] : 'NULL').",
	".(!empty($array_inventorytransaction['sales_cost']) ? $array_inventorytransaction['sales_cost'] : 'NULL').",
	".(!empty($array_inventorytransaction['purchase_return_qty']) ? $array_inventorytransaction['purchase_return_qty'] : 'NULL').",
	".(!empty($array_inventorytransaction['purchase_return_cost']) ? $array_inventorytransaction['purchase_return_cost'] : 'NULL').",
	".(!empty($array_inventorytransaction['sales_return_qty']) ? $array_inventorytransaction['sales_return_qty'] : 'NULL').",
	".(!empty($array_inventorytransaction['sales_return_cost']) ? $array_inventorytransaction['sales_return_cost'] : 'NULL').",
	".(!empty($array_inventorytransaction['adjustment_qty']) ? $array_inventorytransaction['adjustment_qty'] : 'NULL').",
	".(!empty($array_inventorytransaction['adjustment_cost']) ? $array_inventorytransaction['adjustment_cost'] : 'NULL').",
	".(!empty($array_inventorytransaction['challan_id']) ? $array_inventorytransaction['challan_id'] : 'NULL').",
	".(!empty($array_inventorytransaction['challan_no']) ? $array_inventorytransaction['challan_no'] : 'NULL').",
	".$array_inventorytransaction['challan_qty_sent'].",
	".$array_inventorytransaction['challan_qty_receive'].",
	".$array_inventorytransaction['closing_stock'].",
	".$array_inventorytransaction['final_stock'].",
	".(!empty($array_inventorytransaction['discount']) ? $array_inventorytransaction['discount'] : 'NULL').",
	".$array_inventorytransaction['unitprice'].",
	".$array_inventorytransaction['closing_stock_WS_qty'].",
	".(!empty($array_inventorytransaction['vat']) ? $array_inventorytransaction['vat'] : 'NULL')." ,
	".(!empty($array_inventorytransaction['vendor_id']) ? $array_inventorytransaction['vendor_id'] : 'NULL').",
	".$STOREID.",
	'".$STORENAME."',
	NOW()
	) ";
 mysql_query($insert_inventorytransaction) or  die("Line No".__LINE__."   ". mysql_error());
}
//INSERTION DONE HERE FINALLY
//IF EVERY THING GOES WELL CHECK CONNECTION AGAIN
//INSERT CUSTOMER DATA IN SYNC TABLE ON SERVER

foreach($row_local_contactdetails as $key=>$array_contacdetails){

  $insert_contactdetails = "INSERT INTO ".$database_server.".sync_vtiger_contactdetails (contactid,contact_no,accountid,salutation,firstname,lastname,email,phone,mobile,title,department,fax,reportsto,training,usertype,contacttype,otheremail,yahooid,donotcall,emailoptout,imagename,reference,notify_owner,sync_store_id,storename,sync_date) VALUES
(".$array_contacdetails['contactid'].",
'".$array_contacdetails['contact_no']."',
'".(!empty($array_contacdetails['accountid']) ? $array_contacdetails['accountid'] : 'NULL')."',
'".(!empty($array_contacdetails['salutation']) ? $array_contacdetails['salutation'] : 'NULL')."',
'".(!empty($array_contacdetails['firstname']) ? $array_contacdetails['firstname'] : 'NULL')."',
'".(!empty($array_contacdetails['lastname']) ? $array_contacdetails['lastname'] : 'NULL')."',
'".(!empty($array_contacdetails['email']) ? $array_contacdetails['email'] : 'NULL')."',
'".(!empty($array_contacdetails['phone']) ? $array_contacdetails['phone'] : 'NULL')."',
'".(!empty($array_contacdetails['mobile']) ? $array_contacdetails['mobile'] : 'NULL')."',
'".(!empty($array_contacdetails['title']) ? $array_contacdetails['title'] : 'NULL')."',
'".(!empty($array_contacdetails['department']) ? $array_contacdetails['department'] : 'NULL')."',
'".(!empty($array_contacdetails['fax']) ? $array_contacdetails['fax'] : 'NULL')."',
'".(!empty($array_contacdetails['reportsto']) ? $array_contacdetails['reportsto'] : 'NULL')."',
'".(!empty($array_contacdetails['training']) ? $array_contacdetails['training'] : 'NULL')."',
'".(!empty($array_contacdetails['usertype']) ? $array_contacdetails['usertype'] : 'NULL')."',
'".(!empty($array_contacdetails['contacttype']) ? $array_contacdetails['contacttype'] : 'NULL')."',
'".(!empty($array_contacdetails['otheremail']) ? $array_contacdetails['otheremail'] : 'NULL')."',
'".(!empty($array_contacdetails['yahooid']) ? $array_contacdetails['yahooid'] : 'NULL')."',
'".(!empty($array_contacdetails['donotcall']) ? $array_contacdetails['donotcall'] : 'NULL')."',
".$array_contacdetails['emailoptout'].",
'".(!empty($array_contacdetails['imagename']) ? $array_contacdetails['imagename'] : 'NULL')."',
'".(!empty($array_contacdetails['reference']) ? $array_contacdetails['reference'] : 'NULL')."',
".$array_contacdetails['notify_owner'].",
".$STOREID.",
'".$STORENAME."',
NOW()
) ";
 mysql_query($insert_contactdetails) or  die("Line No".__LINE__."   ". mysql_error());
}


foreach($row_local_contactaddress as $key=>$array_contactaddress){
  $insert_contactaddress = "INSERT INTO ".$database_server.".sync_vtiger_contactaddress (contactaddressid,mailingcity,mailingstreet,mailingcountry,othercountry,mailingstate,mailingpobox,othercity,otherstate,mailingzip,otherzip,otherstreet,otherpobox,sync_store_id,storename,sync_date) VALUES
(".$array_contactaddress['contactaddressid'].",
'".(!empty($array_contactaddress['mailingcity']) ? $array_contactaddress['mailingcity'] : 'NULL')."',
'".(!empty($array_contactaddress['mailingstreet']) ? $array_contactaddress['mailingstreet'] : 'NULL')."',
'".(!empty($array_contactaddress['mailingcountry']) ? $array_contactaddress['mailingcountry'] : 'NULL')."',
'".(!empty($array_contactaddress['othercountry']) ? $array_contactaddress['othercountry'] : 'NULL')."',
'".(!empty($array_contactaddress['mailingstate']) ? $array_contactaddress['mailingstate'] : 'NULL')."',
".(!empty($array_contactaddress['mailingpobox']) ? $array_contactaddress['mailingpobox'] : 'NULL').",
'".(!empty($array_contactaddress['othercity']) ? $array_contactaddress['othercity'] : 'NULL')."',
'".(!empty($array_contactaddress['otherstate']) ? $array_contactaddress['otherstate'] : 'NULL')."',
".(!empty($array_contactaddress['mailingzip']) ? $array_contactaddress['mailingzip'] : 'NULL').",
".(!empty($array_contactaddress['otherzip']) ? $array_contactaddress['otherzip'] : 'NULL').",
'".(!empty($array_contactaddress['otherstreet']) ? $array_contactaddress['otherstreet'] : 'NULL')."',
".(!empty($array_contactaddress['otherpobox']) ? $array_contactaddress['otherpobox'] : 'NULL').",
".$STOREID.",
'".$STORENAME."',
NOW()
) ";
 mysql_query($insert_contactaddress) or  die("Line No".__LINE__."   ". mysql_error());
}
//SYNC FOR CASHRECEIPT 
foreach($row_local_cashreceipt as $key=>$array_cashreceipt){
  $insert_local_cashreceipt = "INSERT INTO ".$database_server.".sync_vtiger_cashreceipt (cashreceiptid,invoiceid,customerid,grandtotal,creditamount,paidamount,pendingamount,crediteddate,lastpaiddate,sync_store_id,storename,sync_date) VALUES
(".$array_cashreceipt['cashreceiptid'].",
".$array_cashreceipt['invoiceid'].",
".$array_cashreceipt['customerid'].",
".$array_cashreceipt['grandtotal'].",
".$array_cashreceipt['creditamount'].",
".$array_cashreceipt['paidamount'].",
".$array_cashreceipt['pendingamount'].",
'".$array_cashreceipt['crediteddate']."',
'".$array_cashreceipt['lastpaiddate']."',
".$STOREID.",
'".$STORENAME."',
NOW()
) ";
 mysql_query($insert_local_cashreceipt) or  die("Line No".__LINE__."   ". mysql_error());
}
//SYNC CASHRECEIPT COMPLETED

//SYNC FOR CASHRETURN STARTED

foreach($row_local_cashreturndetails as $key=>$array_cashreturndetails){
  $insert_local_cashreturndetails = "INSERT INTO ".$database_server.".sync_vtiger_cashreturndetails (id,cashreceiptid,amountpaid,datereceived,paymentmethod,bankname,checkno,checkdate,sync_store_id,storename,sync_date) VALUES
(".$array_cashreturndetails['id'].",
".$array_cashreturndetails['cashreceiptid'].",
".$array_cashreturndetails['amountpaid'].",
'".$array_cashreturndetails['datereceived']."',
'".$array_cashreturndetails['paymentmethod']."',
'".(!empty($array_cashreturndetails['bankname']) ? $array_cashreturndetails['bankname'] : 'NULL')."',
'".$array_cashreturndetails['checkno']."',
'".$array_cashreturndetails['checkdate']."',
".$STOREID.",
'".$STORENAME."',
NOW()
) ";
 mysql_query($insert_local_cashreturndetails) or  die("Line No".__LINE__."   ". mysql_error());
}
//SYNC FOR CASHRETURN SUCCESS
//SYNC SALESRETURN DATA

foreach($row_local_salesret as $key=>$array_salesret){
  $insert_local_salesret = "INSERT INTO ".$database_server.".sync_vtiger_salesret (salesid,invoiceid,customername,mobile,email,sync_store_id,storename,sync_date) VALUES
(".$array_salesret['salesid'].",
".$array_salesret['invoiceid'].",
'".$array_salesret['customername']."',
'".$array_salesret['mobile']."',
'".$array_salesret['email']."',
".$STOREID.",
'".$STORENAME."',
NOW()
) ";
 mysql_query($insert_local_salesret) or  die("Line No".__LINE__."   ". mysql_error());
}

foreach($row_local_salereturn_productdetail as $key=>$array_salereturn_productdetail){
  $insert_local_salereturn_productdetail = "INSERT INTO ".$database_server.".sync_salereturn_productdetail (id,salesreturn_id,productid,invoice_qty,unitprice,discount,vat,saleret_qty,saleret_price,sync_store_id,storename,sync_date) VALUES
(".$array_salereturn_productdetail['id'].",
".$array_salereturn_productdetail['salesreturn_id'].",
".$array_salereturn_productdetail['productid'].",
".$array_salereturn_productdetail['invoice_qty'].",
".$array_salereturn_productdetail['unitprice'].",
".$array_salereturn_productdetail['discount'].",
".$array_salereturn_productdetail['vat'].",
".$array_salereturn_productdetail['saleret_qty'].",
".$array_salereturn_productdetail['saleret_price'].",
".$STOREID.",
'".$STORENAME."',
NOW()
) ";
 mysql_query($insert_local_salereturn_productdetail) or  die("Line No".__LINE__."   ". mysql_error());
}
//SYNC SALESRETURN ENDS HERE

//DEBTOR TRANSACTION SYNC

foreach($row_local_debtortransaction as $key=>$array_debtortransaction){
  $insert_local_debtortransaction = "INSERT INTO ".$database_server.".sync_vtiger_debtortransaction (transactionid,date,storeid,userid,username,openingbalance,invid,inv_no,grandtotal,amt_received_by_cash,amt_received_by_card,amt_received_by_check,
salesret_id,amt_return,mode_of_payment,bank_name,checkno,check_date,balance,adjustment,ref_inv_no,closingbalance,modulename,sync_store_id,storename,sync_date) VALUES
(".$array_debtortransaction['transactionid'].",
'".$array_debtortransaction['date']."',
".$array_debtortransaction['storeid'].",
".$array_debtortransaction['userid'].",
'".$array_debtortransaction['username']."',
".$array_debtortransaction['openingbalance'].",
".$array_debtortransaction['invid'].",
'".$array_debtortransaction['inv_no']."',
".$array_debtortransaction['grandtotal'].",
".$array_debtortransaction['amt_received_by_cash'].",
".$array_debtortransaction['amt_received_by_card'].",
".$array_debtortransaction['amt_received_by_check'].",
".(!empty($array_debtortransaction['salesret_id']) ? $array_debtortransaction['salesret_id'] : 'NULL').",
".$array_debtortransaction['amt_return'].",
'".(!empty($array_debtortransaction['mode_of_payment']) ? $array_debtortransaction['mode_of_payment'] : 'NULL')."',
'".(!empty($array_debtortransaction['bank_name']) ? $array_debtortransaction['bank_name'] : 'NULL')."',
".(!empty($array_debtortransaction['checkno']) ? $array_debtortransaction['checkno'] : 'NULL').",
'".(!empty($array_debtortransaction['check_date']) ? $array_debtortransaction['check_date'] : 'NULL')."',
".$array_debtortransaction['balance'].",
".$array_debtortransaction['adjustment'].",
'".(!empty($array_debtortransaction['ref_inv_no']) ? $array_debtortransaction['ref_inv_no'] : 'NULL')."',
".$array_debtortransaction['closingbalance'].",
'".$array_debtortransaction['modulename']."',
".$STOREID.",
'".$STORENAME."',
NOW()
) ";

 mysql_query($insert_local_debtortransaction) or  die("Line No".__LINE__."   ". mysql_error());
}
//DEBTOR TRANSACTION ENDS HERE
//DATA INSERTED SUCCESS
echo "<br />";
echo pingHost();
//IF CONNECTION IS ACTIVE
//SAVE CONFIGURATION IN sync_configuration table on server

$save_configuration = "INSERT INTO ".$database_server.".sync_configuration(sync_store_id,total_hits,sync_date,storename,sync_status) VALUES
(".$STOREID.",1,NOW(),'".$STORENAME."',1) ";
mysql_query($save_configuration) or  die("Line No".__LINE__."   ". mysql_error());
echo "<br />";
echo "DATA SYNCHRONIZED SUCCESS ! NOW YOU CAN CLOSE BROWSER";
}elseif($row_server_sync_store_status['sync_status'] == 0 ){
echo "Deleted  previous enteries :: ";
echo "<B>"."Please Run the Script Again"."</B>";
$q1 = "DELETE FROM ".$database_server.".sync_vtiger_crmentity WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q1) or  die("Line No".__LINE__."   ". mysql_error());
$q2 = "DELETE FROM ".$database_server.".sync_vtiger_invoice WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q2) or  die("Line No".__LINE__."   ". mysql_error());
$q3 = "DELETE FROM ".$database_server.".sync_vtiger_inventoryproductrel WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q3) or  die("Line No".__LINE__."   ". mysql_error());
$q4 = "DELETE FROM ".$database_server.".sync_vtiger_inventorytransaction WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q4) or  die("Line No".__LINE__."   ". mysql_error());
$q5 = "DELETE FROM ".$database_server.".sync_vtiger_warehousestore_inventorytransaction WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q5) or  die("Line No".__LINE__."   ". mysql_error());

$q6 = "DELETE FROM ".$database_server.".sync_configuration WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q6) or  die("Line No".__LINE__."   ". mysql_error());

$q7 = "DELETE FROM ".$database_server.".sync_vtiger_contactaddress WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q7) or  die("Line No".__LINE__."   ". mysql_error());

$q8 = "DELETE FROM ".$database_server.".sync_vtiger_contactdetails WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q8) or  die("Line No".__LINE__."   ". mysql_error());

$q9 = "DELETE FROM ".$database_server.".sync_vtiger_cashreceipt WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q9) or  die("Line No".__LINE__."   ". mysql_error());

$q10 = "DELETE FROM ".$database_server.".sync_vtiger_cashreturndetails WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q10) or  die("Line No".__LINE__."   ". mysql_error());

$q11 = "DELETE FROM ".$database_server.".sync_vtiger_debtortransaction WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q11) or  die("Line No".__LINE__."   ". mysql_error());

$q12 = "DELETE FROM ".$database_server.".sync_vtiger_inventoryproductrel WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q12) or  die("Line No".__LINE__."   ". mysql_error());

$q13 = "DELETE FROM ".$database_server.".sync_salereturn_productdetail WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q13) or  die("Line No".__LINE__."   ". mysql_error());

$q14 = "DELETE FROM ".$database_server.".sync_vtiger_salesret WHERE sync_store_id = ".$STOREID." AND DATE_FORMAT(sync_date,'%Y-%m-%d') = '".$curr_date."' ";
mysql_query($q14) or  die("Line No".__LINE__."   ". mysql_error());
//TO DO GIRISH AT END OF THE SCRIPT COMPLETION
//Delete all temp tables and run script again
exit;

}elseif($row_server_sync_store_status['sync_status'] == 1){
//DATA Allready Inserted 
echo "Data Is Allready Synchronized ";
exit;
}
?>