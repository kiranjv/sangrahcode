<?php 
error_reporting(1);
//SERVER SCRIPT TO IMPORT DATA FROM TEMP TO FINAL TABLES FOR SALES,CASHRETURN,SALES RETURN,TRANSACTIONS
?>
<?php
//SERVER DATABASE
$database_server = "sangrah_guwahati";
$dbserver = mysql_connect('localhost','root','');
	if (!$dbserver) {
		die('Could not connect to server: ' . mysql_error());
	}
mysql_select_db($database_server,$dbserver);
?>
<?php
$fetch_crmentity = "SELECT crmid FROM vtiger_crmentity ORDER BY DESC LIMIT 1";
$result_crmentity = mysql_query($fetch_crmentity);
$row_crmentity = mysql_fetch_array($result_crmentity);
print_r($row_crmentity);

?>